import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addorders',
  templateUrl: './addorders.component.html',
  styleUrls: ['./addorders.component.css']
})
export class AddordersComponent implements OnInit {

  

  constructor() { }


  ngOnInit(){
      }
}
