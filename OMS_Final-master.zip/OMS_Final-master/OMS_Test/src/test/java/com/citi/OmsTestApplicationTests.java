package com.citi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OmsTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
